package proyecto.loteria;

import java.util.Date;

/**
 * @Author Antonio Rodríguez Sirgado
 */
public class Navidad {
    String numero;
    String serie;
    String fraccion;
    String euros;
    Date fecha;
}
